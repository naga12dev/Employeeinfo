//
//  EmployeeInfoViewController.swift
//  EmployeeDirectory
//
//  Created by Nerella, Hanu Naga Mounika on 10/12/22.
//

import UIKit

class EmployeeInfoViewController: UIViewController, EmployeeViewModelDelegate {
    
    @IBOutlet weak var employeeList: UITableView!
    
    let refreshControl = UIRefreshControl()
    var error: NetworkErrors?
    var viewModel = EmployeeViewModel(apiManager: APIManager())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.fetchEmployeeInformation()
        viewModel.delegate = self
        employeeList.refreshControl = refreshControl
        employeeList.delegate = self
        employeeList.dataSource = self
        refreshControl.addTarget(self, action: #selector(refresh), for: UIControl.Event.valueChanged)
    }
    
    
    var dataSource: UITableViewDiffableDataSource<Section, Item>! = nil
    private var imageObjects = [Item]()
    
    
    @objc
    func refresh(){
        viewModel.fetchEmployeeInformation()
    }
    
    func update(with error: NetworkErrors?) {
        refreshControl.endRefreshing()
        self.error = error
        employeeList.reloadData()
    }

}
extension EmployeeInfoViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (error == nil || !viewModel.results.isEmpty) ? viewModel.results.count : 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if error != nil || viewModel.results.isEmpty {
            let cell = employeeList.dequeueReusableCell(withIdentifier: "ErrorCell", for:indexPath)
        
            if error != nil {
                cell.textLabel?.text = error?.localizedDescription
            } else {
                cell.textLabel?.text = "No Contacts found"
            }
            
            return cell
        }
        
        guard let cell = employeeList.dequeueReusableCell(withIdentifier: "detailsTableView", for: indexPath) as? EmployeeListTableViewCell else {
            return UITableViewCell()
        }
        cell.empInfo = viewModel.results[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
}
