//
//  EmployeeViewModel.swift
//  EmployeeDirectory
//
//  Created by Nerella, Hanu Naga Mounika on 10/12/22.
//

import Foundation
// View Model
protocol EmployeeViewModelDelegate: AnyObject {
    func update(with error: NetworkErrors?)
}

class EmployeeViewModel {
    var results = [Employee]()
    let apiManager: APIManagerProtocol
    weak var delegate: EmployeeViewModelDelegate?
    
    init(apiManager: APIManagerProtocol) {
        self.apiManager = apiManager
    }
    
    func fetchEmployeeInformation(){
        apiManager.fetchContacts { [weak self] response in
            DispatchQueue.main.async {
                switch response {
                case .success(let employeeData):
                    self?.results = employeeData.employees.sorted(by: { $0.fullName < $1.fullName })
                    self?.delegate?.update(with: nil)
                case .failure(let error):
                    self?.delegate?.update(with: error)
                }
            }
        }
    }
}
