//
//  APIManager.swift
//  EmployeeDirectory
//
//  Created by Nerella, Hanu Naga Mounika on 10/17/22.
//

import Foundation

protocol APIManagerProtocol {
    func fetchContacts(onCompletion handler: @escaping(Result<EmployeeInfoModel, NetworkErrors>) -> Void)
}

class APIManager: APIManagerProtocol {
    func fetchContacts(onCompletion handler: @escaping(Result<EmployeeInfoModel, NetworkErrors>) -> Void) {
        NetworkLayer.standard.request(type: .get, path: Controllers.employeeInformation.rawValue, completion: handler)
    }
}

class TestAPIManager: APIManagerProtocol {
    func fetchContacts(onCompletion handler: @escaping(Result<EmployeeInfoModel, NetworkErrors>) -> Void) {
        let empInfoModel = EmployeeInfoModel(employees:
                                [Employee(uuid: "123",
                                          fullName: "Donald Trump",
                                          phoneNumber: "1234567890",
                                          emailAddress: "donald@gmail.com",
                                          biography: "45th President of USA",
                                          photoURLSmall: "",
                                          photoURLLarge: "",
                                          team: "Republican",
                                          employeeType: .contractor),
                                ]             
        )
        
        handler(.success(empInfoModel))
    }
}
